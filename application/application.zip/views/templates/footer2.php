 
        <!-- LOAD FILES AT PAGE END FOR FASTER LOADING -->
        <!-- CORE JS FRAMEWORK - START --> 
        <script src="<?php echo base_url()?>assets/js/jquery.easing.min.js" type="text/javascript"></script> 
        <script src="<?php echo base_url()?>assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script> 
        <script src="<?php echo base_url()?>assets/plugins/pace/pace.min.js" type="text/javascript"></script>  
        <script src="<?php echo base_url()?>assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js" type="text/javascript"></script> 
        <script src="<?php echo base_url()?>assets/plugins/viewport/viewportchecker.js" type="text/javascript"></script>  
        <!-- CORE JS FRAMEWORK - END --> 
        <script src="<?php echo base_url()?>assets/js/scripts.js" type="text/javascript"></script> 
        <script src="<?php echo base_url()?>assets/plugins/datepicker/js/datepicker.js" type="text/javascript"></script> 
        <script src="<?php echo base_url()?>assets/plugins/daterangepicker/js/moment.min.js" type="text/javascript"></script> 
        <script src="<?php echo base_url()?>assets/plugins/daterangepicker/js/daterangepicker.js" type="text/javascript"></script> 
        <script src="<?php echo base_url()?>assets/plugins/timepicker/js/bootstrap-timepicker.min.js" type="text/javascript"></script> 
        <script src="<?php echo base_url()?>assets/plugins/datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script> 
        <script src="<?php echo base_url()?>assets/plugins/datetimepicker/js/locales/bootstrap-datetimepicker.fr.js" type="text/javascript"></script> 
                
        <!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - START --> 
        <script src="<?php echo base_url()?>assets/plugins/datatables/js/jquery.dataTables.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables/extensions/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url()?>assets/plugins/datatables/extensions/Responsive/bootstrap/3/dataTables.bootstrap.js" type="text/javascript"></script><!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END -->   
        
        <script src="<?php echo base_url()?>assets/plugins/autosize/autosize.min.js" type="text/javascript"></script><script src="assets/plugins/icheck/icheck.min.js" type="text/javascript"></script><!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END --> 

         <!-- CORE TEMPLATE JS - START --> 
        
        <!-- END CORE TEMPLATE JS - END --> 
    </body>
</html>
